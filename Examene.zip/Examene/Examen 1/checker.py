import requests

SITES = [
    # Pagini obișnuite (Părțile 2, 3 și 4)
    "https://example.com",
    "https://httpbin.org/html",
    "https://httpbin.org/json",
    "https://httpbin.org/status/200",
    "https://httpbin.org/redirect/1",
    "https://httpbin.org/delay/2",
    # Pagini care eșuează
    "https://httpbin.org/status/404",
    "https://httpbin.org/status/500",
    "https://httpbin.org/delay/10",
    "http://this-site-does-not-exist.invalid",
    # Anteturi de securitate (Partea 5)
    "https://httpbin.org/response-headers?X-Frame-Options=DENY&X-Content-Type-Options=nosniff",
    "https://httpbin.org/response-headers?x-frame-options=DENY",
    # Răspunde aleatoriu cu 200 sau 500 (Partea 6)
    "https://httpbin.org/status/200,500",
]

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
]


def build_url(host, path):
    """Returnează o adresă completă, de exemplu https://example.com/login."""
    if path.startswith("/"):
     response = host + path
    else:
     response = host + "/" + path
    return response
print(build_url(SITES[0], "/get"))
print(build_url(SITES[1], "get"))

def is_https(url):
    """Returnează True dacă adresa începe cu https://, altfel False."""
    if url.startswith("https://"):
     return True
    else:
     return False
print(is_https(SITES[0]))
print(is_https("test"))

def show_response(url):
    """Trimite un GET la url și afișează statusul și Content-Type."""
    response = requests.get(url)
    response.headers.get("Content-Type", "unknown")
    print("Status:", response.status_code)
    print("Content-Type:", response.headers.get("Content-Type", "unknown"))
    return response
print(show_response(SITES[0]))


def check_site(url):
    """Returnează un dicționar cu: status, content_type, length, server."""
    try:
        response = requests.get(url, timeout=5)
        return { "status": response.status_code, "content_type": response.headers.get("Content-Type", "unknown"),
                "length": len(response.content), "server": response.headers.get("Server", "unknown") }
    except requests.RequestException as e:
            return { "status": None, "error": str(e)}
print(check_site(SITES[0]))

def scan_sites():
    """Verifică toate site-urile din SITES, afișează-le pe cele care merg și un rezumat."""
    rezultate = []
    for url in SITES:
        rezultat = check_site(url)
        if rezultat["status"] == 200:
            rezultate.append((url, rezultat))
    rezultate.sort(key=lambda x: x[1]["length"], reverse=True)
    for url, rezultat in rezultate:
        print(url, "->", rezultat["status"], rezultat["length"], "octeți")
    print("Reușite:", len(rezultate))
    print("Eșuate:", len(SITES) - len(rezultate))
print(scan_sites())

def check_headers(url):
    try:
        response = requests.get(url, timeout=5)
        present = []
        missing = []

        for header in SECURITY_HEADERS:
            if header in response.headers:
                present.append(header)
            else:
                missing.append(header)

        score = int(len(present) / len(SECURITY_HEADERS) * 100)

        return {"present": present, "missing": missing, "score": score}

    except requests.RequestException as e:
        return {"status": None, "error": str(e)}
print(check_headers(SITES[0]))
def retry_check(url, attempts=3):
    """Încearcă de cel mult `attempts` ori; returnează un dicționar cu: status, attempts."""
    pass