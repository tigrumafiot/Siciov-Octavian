# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

"""Programul principal: import, argparse, CSV și raport JSON (ex. 44–50)."""
import argparse
import csv
from datetime import datetime
from urllib.parse import urlparse
import requests
import webtools  # Exercițiul 44: importarea întregului modul.
from webtools import get_title, security_headers, DEFAULT_HEADERS  # Ex. 45 și 47.

# Dacă am defini aici o funcție get_title(), aceasta ar înlocui numele
# importat și apelul get_title() ar folosi funcția locală.


def save_csv(url, paths, filename="report.csv"):
    """Salvează în CSV codurile de stare ale unor căi (ex. 49)."""
    results = webtools.check_paths(url, paths)
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["path", "status", "checked_at"])
        writer.writeheader()
        for path, status in results.items():
            writer.writerow({"path": path, "status": status, "checked_at": datetime.now().isoformat()})
    print("Salvat în", filename)


def main():
    """Primește URL-ul din linia de comandă și execută exercițiile."""
    parser = argparse.ArgumentParser(description="Laborator Python: raport despre un site")
    parser.add_argument("url", nargs="?", default="https://cybercor.org", help="URL-ul site-ului")
    args = parser.parse_args()
    url = args.url
    if urlparse(url).scheme not in ("http", "https"):
        parser.error("Adresa trebuie să înceapă cu http:// sau https://")
    print("DEFAULT_HEADERS:", DEFAULT_HEADERS)
    try:
        # Ex. 44: apel prin modulul webtools.
        print("Titlu (webtools):", webtools.get_title(webtools.fetch(url).text))
        # Ex. 45: apel prin import direct.
        print("Titlu (import direct):", get_title(webtools.fetch(url).text))
        print("Antete securitate:", security_headers(url))
        save_csv(url, ["/", "/robots.txt", "/sitemap.xml"])
        webtools.site_report(url)
    except (requests.RequestException, OSError, ValueError) as error:
        print("Eroare la accesarea site-ului:", error)


if __name__ == "__main__":
    main()
