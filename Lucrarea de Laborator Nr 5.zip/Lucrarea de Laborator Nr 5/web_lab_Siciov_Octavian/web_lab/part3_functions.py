# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiu 21

# import requests
# def fetch(url):
#     response = requests.get(url, timeout=TIMEOUT)
#     return response
# response = fetch(BASE_URL)
# print(response.status_code)

# Exercițiu 22

# import requests
# import time
# def get_status(url):
#     response = requests.get(url, timeout=TIMEOUT)
#     return response.status_code
# response1 = get_status(BASE_URL + "/")
# print(response1)
# time.sleep(1)
# response2 = get_status(BASE_URL + "/robots.txt")
# print(response2)
# time.sleep(1)
# response3 = get_status(BASE_URL + "/sitemap.xml")
# print(response3)

# Exercițiu 23

# import requests
# import time
# def fetch(url, timeout=10):
#     response = requests.get(url, timeout=timeout)
#     return response
# response = fetch(BASE_URL)
# print(response.status_code)
# time.sleep(1)
# response = fetch(BASE_URL, timeout=3)
# print(response.status_code)

# Exercițiu 24

# import requests
# response = requests.get(BASE_URL, timeout=10)
# def get_title(html):
#     start = html.find("<title>") + len("<title>")
#     end = html.find("</title>")
#     return html[start:end].strip()
# titlu = get_title(response.text)
# print(titlu)

# Exercițiu 25

# import requests
# response = requests.get(BASE_URL, timeout=10)
# def get_title(html):
#     """Extrage titlul din HTML."""
#     start = html.find("<title>") + len("<title>")
#     end = html.find("</title>")
#     return html[start:end].strip()
# titlu = get_title(response.text)
# print(titlu)
# help(get_title)

# Exercițiu 26

# import requests
# def get_status(url: str) -> int:
#     response = requests.get(url, timeout=TIMEOUT)
#     return response.status_code
# response = get_status(BASE_URL)
# print(response)
# print(get_status(123))
# Adnotările de tip ne ajută să înțelegem ce tipuri de date trebuie folosite,
# dar nu împiedică executarea funcției cu alte tipuri.

# Exercițiu 27

# import requests
# import time
# def page_exists(url):
#     try:
#         response = requests.get(url, timeout=TIMEOUT)
#         return response.status_code == 200
#     except requests.RequestException:
#         return False
# print(page_exists(BASE_URL))
# time.sleep(1)
# print(page_exists("https://this-domain-does-not-exist.invalid"))

# Exercițiu 28

# import requests
# def check_paths(base, paths):
#     rezultate = {}
#     for path in paths:
#         response = requests.get(base + path, timeout=TIMEOUT)
#         rezultate[path] = response.status_code
#     return rezultate
# print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml", "/this-page-does-not-exist"]))

# Exercițiu 29

# import requests
# def get_header(url, name, default="lipsește"):
#     response = requests.get(url, timeout=TIMEOUT)
#     return response.headers.get(name, default)
# print(get_header(BASE_URL, name="Server"))

# Exercițiu 30

# import requests
# def security_headers(url):
#     response = requests.get(url, timeout=TIMEOUT)
#     rezultate = {}
#     antete = [
#     "Strict-Transport-Security",
#     "Content-Security-Policy",
#     "X-Frame-Options",
#     "X-Content-Type-Options",
#     "Referrer-Policy"
#     ]
#     for antet in antete:
#         rezultate[antet] = antet in response.headers
#     return rezultate
# print(security_headers(BASE_URL))

# Exercițiu 31

# import requests
# def security_headers(url):
#     response = requests.get(url, timeout=TIMEOUT)
#     rezultate = {}
#     antete = [
#     "Strict-Transport-Security",
#     "Content-Security-Policy",
#     "X-Frame-Options",
#     "X-Content-Type-Options",
#     "Referrer-Policy"
#     ]
#     for antet in antete:
#         rezultate[antet] = antet in response.headers
#     return rezultate
# def score_headers(results):
#     prezente = sum(results.values())
#     total = len(results)
#     return f"{prezente}/{total}"
# print(score_headers(security_headers(BASE_URL)))

# Exercițiu 32

# import requests
# def fetch_robots(base):
#     response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
#     if response.status_code == 200:
#         return response.text
#     else:
#         return None
# def disallowed_paths(robots_text):
#     rezultate = []
#     if robots_text is None:
#         return rezultate
#     for line in robots_text.splitlines():
#         line = line.strip()
#         if line.startswith("Disallow:"):
#             path = line[len("Disallow:"):].strip()
#             rezultate.append(path)
#     return rezultate
# robots_text = fetch_robots(BASE_URL)
# print(disallowed_paths(robots_text))

# Exercițiu 33

# import requests
# def response_times(*urls):
#     rezultate = {}
#     for url in urls:
#         response = requests.get(url, timeout=TIMEOUT)
#         rezultate[url] = response.elapsed.total_seconds()
#     return rezultate
# print(response_times(BASE_URL,"https://httpbin.org", "https://www.google.com"))

# Exercițiu 34

# import requests
# def log(message, **details):
#     print(message, end="")
#     for cheie, valoare in details.items():
#         print(f" | {cheie}={valoare}", end="")
#     print()
# log("verificat", url=BASE_URL, status=200)

# print() doar afișează valoarea în consolă, iar return trimite valoarea înapoi din funcție,
# pentru a putea fi folosită mai departe în program.