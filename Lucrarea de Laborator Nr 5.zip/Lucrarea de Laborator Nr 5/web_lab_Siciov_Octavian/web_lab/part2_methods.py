# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiu 9

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# print(response.status_code) # atribut
# print(response.ok) # atribut
# print(response.url) # atribut
# print(response.encoding) # atribut
# Atribut este o informație/valoare pe care obiectul o are.
# Metodă este o acțiune pe care obiectul o poate face. De obicei o recunoști după paranteze ().

# Exercițiu 10

# import requests
# try:
#     response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
#     response.raise_for_status()
# except requests.HTTPError:
#     print("Pagina nu există.")

# Exercițiu 11

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# for header, value in response.headers.items():
#     print(header + ": " + value)

# Exercițiu 12

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# server = response.headers.get("Server", "lipsește")
# content_type = response.headers.get("content-Type", "lipsește")
# print("Content-Type: " + content_type)
# print("Server: " + server)
# Nu observ nicio schimbare, deoarece cheile nu sunt sensibile la litere mari și mici.

# Exercițiu 13

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# count = response.text.lower().count("cyber")
# print(count)
# Se ia textul, apoi este transformat în litere mici și în final se numără aparițiile cuvântului cyber.

# Exercițiu 14

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# start = response.text.find("<title>") + len("<title>")
# end = response.text.find("</title>")
# print(response.text[start:end].strip()) # text[de_unde : până_unde]

# Exercițiu 15

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# lines = response.text.splitlines()
# print(len(lines))
# print(len(max(lines, key=len)))

# Exercițiu 16

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# if response.url.startswith("https://"):
#     print("Pagina este securizată.")
# else:
#     print("Pagina nu este securizată.")

# Exercițiu 17

# import requests
# response = requests.get("http://cybercor.org", timeout=TIMEOUT)
# for redirectionare in response.history:
#     print(redirectionare.status_code)
#     print(redirectionare.url)
# print(response.url)

# Exercițiu 18

# import requests
# get_response = requests.get(BASE_URL, timeout=TIMEOUT)
# head_response = requests.head(BASE_URL, timeout=TIMEOUT)
# print("Get: " + str(len(get_response.content)))
# print("Head: " + str(len(head_response.content)))
# GET are 1540 bytes deoarece primește conținutul paginii, iar HEAD are 0 bytes deoarece nu primește conținutul.

# Exercițiu 19

# import requests
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# if len(response.cookies) == 0:
#     print("Niciun cookie setat.")
# else:
#     for cookie in response.cookies:
#         print(cookie.name)
#         print(cookie.secure)

# Exercițiu 20

# import requests
# sesiune = requests.Session()
# sesiune.headers.update({"User-Agent": "Sîciov Octavian"})
# response = sesiune.get(ECHO_URL + "/headers", timeout=TIMEOUT)
# print(response.json())
# print(response.text)
# response.text este un atribut de aceea nu are (), iar response.json() este o metodă de aceea are ().