# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiu 35

# from urllib.parse import urlparse
# def descompune_url(url):
#     """Afișează componentele principale ale unui URL (ex. 35)."""
#     rezultat = urlparse(url)
#     print(rezultat.scheme, rezultat.netloc, rezultat.path, rezultat.query, rezultat.fragment)
# descompune_url("https://cybercor.org/path?x=1#top")

# Exercițiu 36

# from urllib.parse import urljoin
# def compune_url(base, links):
#     """Afișează URL-uri absolute din legături relative (ex. 36)."""
#     for link in links:
#         print(urljoin(base, link))
# links = ["/about", "contact.html", "../index.html"]
# compune_url(BASE_URL, links)

# Exercițiu 37

# import requests
# import re
# def extract_links(html):
#     """Extrage legăturile href fără duplicate (ex. 37)."""
#     return list(set(re.findall(r'href="([^"]+)"', html)))
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# html = response.text
# print(extract_links(html))

# Exercițiu 38

# import requests
# import re
# from urllib.parse import urljoin, urlparse
# def extract_links(html):
#     """Extrage legăturile href fără duplicate (ex. 37)."""
#     return list(set(re.findall(r'href="([^"]+)"', html)))
# def split_links(links, domain):
#     """Separă legăturile interne și externe (ex. 38)."""
#     interne, externe = [], []
#     for link in links:
#         complet = urljoin(BASE_URL, link)
#         if urlparse(complet).netloc == domain:
#             interne.append(complet)
#         else:
#             externe.append(complet)
#     return interne, externe
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# html = response.text
# links = extract_links(html)
# interne, externe = split_links(links, "cybercor.org")
# print("Interne:", interne)
# print("Externe:", externe)

# Exercițiu 39

# import requests
# from html.parser import HTMLParser
# class ImageFinder(HTMLParser):
#     """Colectează valorile src din elementele img (ex. 39)."""
#     def __init__(self):
#         """Inițializează parserul și lista de imagini."""
#         super().__init__()
#         self.images = []
#
#     def handle_starttag(self, tag, attrs):
#         """Adaugă src când este întâlnit un tag img."""
#         if tag == "img":
#             src = dict(attrs).get("src")
#             if src is not None:
#                 self.images.append(src)
# test_html = """<html><body>
# <img src="/logo.png" alt="Logo">
# <IMG SRC="poza.jpg">
# <img alt="imagine fără src">
# <img src="https://cdn.example.com/banner.webp" />
# <a href="/despre">Link</a>
# </body></html>"""
# finder = ImageFinder()
# finder.feed(test_html)
# print(finder.images)
# assert finder.images == ["/logo.png", "poza.jpg", "https://cdn.example.com/banner.webp"]
# print("Testul a trecut!")
# response = requests.get(BASE_URL, timeout=TIMEOUT)
# finder = ImageFinder()
# finder.feed(response.text)
# print(len(finder.images), "imagini găsite")
# for src in finder.images:
#     print(src)
# print("Tag-uri img:", response.text.lower().count("<img"))
# # Parserul găsește doar imagini din tag-uri img, nu cele din CSS sau SVG.

# Exercițiu 40

# import requests
# import hashlib
# import time
# def page_fingerprint(url):
#     """Returnează amprenta SHA-256 a paginii (ex. 40)."""
#     response = requests.get(url, timeout=TIMEOUT)
#     response.raise_for_status()
#     return hashlib.sha256(response.content).hexdigest()
# prima = page_fingerprint(BASE_URL)
# time.sleep(1)
# a_doua = page_fingerprint(BASE_URL)
# print(prima)
# print(a_doua)
# print(prima == a_doua)
# # Amprentele diferă dacă se schimbă conținutul paginii.

# Exercițiu 41

# import requests
# import json
# def save_headers(url, filename="headers.json"):
#     """Salvează antetele HTTP în JSON și le citește înapoi (ex. 41)."""
#     response = requests.get(url, timeout=TIMEOUT)
#     response.raise_for_status()
#     with open(filename, "w", encoding="utf-8") as file:
#         json.dump(dict(response.headers), file, indent=2)
#     with open(filename, "r", encoding="utf-8") as file:
#         loaded = json.load(file)
#     print("Content-Type:", loaded.get("Content-Type", "lipsește"))
#     return loaded
# save_headers(BASE_URL)

# Exercițiu 42

# import socket
# def resolve(hostname):
#     """Returnează adresa IPv4 a unui domeniu (ex. 42)."""
#     return socket.gethostbyname(hostname)
# print(resolve("cybercor.org"))

# Exercițiu 43

# import socket
# import ssl
# from datetime import datetime, timezone
# def cert_days_left(hostname):
#     """Returnează zilele întregi rămase până la expirarea certificatului (ex. 43)."""
#     context = ssl.create_default_context()
#     with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
#         with context.wrap_socket(sock, server_hostname=hostname) as secure:
#             expires = secure.getpeercert()["notAfter"]
#     seconds = ssl.cert_time_to_seconds(expires)
#     return int((datetime.fromtimestamp(seconds, timezone.utc) - datetime.now(timezone.utc)).total_seconds() // 86400)
# print(cert_days_left("cybercor.org"))
# # handle_starttag() este apelată automat de HTMLParser când folosim feed().
