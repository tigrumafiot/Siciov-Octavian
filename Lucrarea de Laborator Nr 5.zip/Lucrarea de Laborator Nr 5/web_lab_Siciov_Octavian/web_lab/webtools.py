# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

"""Funcții reutilizabile pentru verificarea unui site (exercițiile 44–50)."""
import json
import time
import re
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse
import requests

TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Siciov-Octavian"}
_last_request_time = None

SECURITY_HEADERS = [
    "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
    "X-Content-Type-Options", "Referrer-Policy"
]


def fetch(url, timeout=TIMEOUT):
    """Descarcă o pagină și returnează obiectul Response."""
    global _last_request_time
    # Respectăm pauza minimă de o secundă între toate cererile HTTP.
    if _last_request_time is not None:
        remaining = 1 - (time.monotonic() - _last_request_time)
        if remaining > 0:
            time.sleep(remaining)
    _last_request_time = time.monotonic()
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url):
    """Returnează codul HTTP al paginii."""
    return fetch(url).status_code


def get_title(html):
    """Extrage titlul dintre tag-urile title."""
    match = re.search(r"<title[^>]*>(.*?)</title\s*>", html, flags=re.I | re.S)
    return match.group(1).strip() if match else "Titlu lipsă"


def security_headers(url):
    """Verifică prezența celor cinci antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADERS}


def score_headers(results):
    """Calculează scorul antetelor prezente, de forma 3/5."""
    return f"{sum(results.values())}/{len(results)}"


def check_paths(base, paths):
    """Returnează un dicționar cu codurile HTTP pentru căi."""
    import time
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        try:
            results[path] = fetch(urljoin(base.rstrip("/") + "/", path.lstrip("/"))).status_code
        except requests.RequestException:
            results[path] = "eroare"
    return results


def resolve(hostname):
    """Returnează IP-ul domeniului."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname):
    """Returnează numărul de zile până la expirarea certificatului."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            expiry = secure.getpeercert()["notAfter"]
    return int((ssl.cert_time_to_seconds(expiry) - datetime.now(timezone.utc).timestamp()) // 86400)


def extract_links(html):
    """Extrage href-urile fără duplicate."""
    return list(set(re.findall(r'href="([^"]+)"', html)))


def split_links(links, base):
    """Returnează listele de URL-uri interne și externe."""
    internal, external = [], []
    domain = urlparse(base).netloc
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


def fetch_robots(base):
    """Returnează robots.txt sau None dacă nu este disponibil."""
    response = fetch(urljoin(base.rstrip("/") + "/", "robots.txt"))
    return response.text if response.status_code == 200 else None


def disallowed_paths(robots_text):
    """Extrage toate valorile Disallow din robots.txt."""
    if robots_text is None:
        return []
    return [line.split(":", 1)[1].strip() for line in robots_text.splitlines()
            if line.strip().lower().startswith("disallow:")]


def site_report(url):
    """Colectează, afișează și salvează raportul site-ului în report.json."""
    import time
    response = fetch(url)
    hostname = urlparse(response.url).hostname
    report = {
        "url_final": response.url,
        "status": response.status_code,
        "titlu": get_title(response.text),
    }
    try:
        report["ip"] = resolve(hostname)
    except OSError as error:
        report["ip"] = f"Indisponibil: {error}"
    try:
        # Pornim de la http:// pentru a observa redirecționările.
        initial = "http://" + urlparse(url).netloc + (urlparse(url).path or "/")
        redirected = fetch(initial)
        report["redirectari"] = [f"{item.status_code} -> {item.headers.get('Location', item.url)}" for item in redirected.history]
        report["redirectari"].append(f"Final: {redirected.url}")
    except requests.RequestException as error:
        report["redirectari"] = [f"Indisponibil: {error}"]
    time.sleep(1)
    try:
        report["scor_securitate"] = score_headers(security_headers(response.url))
    except requests.RequestException as error:
        report["scor_securitate"] = f"Indisponibil: {error}"
    try:
        report["zile_certificat"] = cert_days_left(hostname)
    except (OSError, ssl.SSLError, ValueError, KeyError) as error:
        report["zile_certificat"] = f"Indisponibil: {error}"
    interne, externe = split_links(extract_links(response.text), response.url)
    report["legaturi_interne"] = len(interne)
    report["legaturi_externe"] = len(externe)
    time.sleep(1)
    try:
        report["cai_interzise"] = disallowed_paths(fetch_robots(response.url))
    except requests.RequestException as error:
        report["cai_interzise"] = [f"Indisponibil: {error}"]

    print(f"=== Raport site: {url} ===")
    print("Cod de stare:", report["status"])
    print("URL final:", report["url_final"])
    print("Titlu:", report["titlu"])
    print("Adresă IP:", report["ip"])
    print("Redirecționări:", "; ".join(report["redirectari"]))
    print("Scor securitate:", report["scor_securitate"])
    print("Certificat:", report["zile_certificat"], "zile rămase")
    print("Legături:", report["legaturi_interne"], "interne,", report["legaturi_externe"], "externe")
    print("Căi interzise:", ", ".join(report["cai_interzise"]) or "niciuna")
    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print("Salvat în report.json")
    return report


if __name__ == "__main__":
    # Autotestul rulează numai când executăm direct webtools.py,
    # nu când importăm webtools în main.py.
    try:
        print("Autotest:", get_status("https://cybercor.org"))
    except requests.RequestException as error:
        print("Autotest indisponibil:", error)
