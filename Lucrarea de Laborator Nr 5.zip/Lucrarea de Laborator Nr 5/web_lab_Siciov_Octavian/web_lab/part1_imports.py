# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiu 1

# import requests
# import urllib.request
# print(requests.__version__)
# Requests este o bibliotecă externa si de aceea a fost nevoie de pip install, urllib face din biblioteca standard python.

# Exercițiu 2

# import requests
# Status = requests.get(BASE_URL,  timeout=TIMEOUT)
# print(Status.status_code)
# Cu "import requests" trebuie să scrii requests.get(). Avantaj: se vede clar că get() vine din requests.

# from requests import get
# Status = get(BASE_URL, timeout=TIMEOUT)
# print(Status.status_code)
# Cu "from requests import get" poți scrie direct get(). Avantaj: codul este mai scurt.

# Exercițiu 3

# import requests as rq
# Status = rq.get(BASE_URL, timeout=TIMEOUT)
# print(Status.status_code)
# Un alias poate face un cod mai ușor de citit și mai scurt.
# De exemplu, requests poate fi înlocuit cu rq.
# Dar sunt cazuri în care aliasul poate fi confuz, de exemplu alegi un alias precum x, altcineva nu va ști ce înseamnă x.
# De aceea, este recomandat să alegi un alias care să aibă sens și să fie ușor de înțeles.

# Exercițiu 4

# import urllib.request
# Status = urllib.request.urlopen(BASE_URL, timeout=TIMEOUT)
# Text = Status.read().decode("utf-8")
# print(Text[:200])
# print(Status.status)

# Exercițiu 5

# import requests
# print(dir(requests))
# print(type(requests.get)) # Funcție, execută o anumită acțiune.
# print(type(requests.Session)) # Clasă, un șablon din care pot fi create obiecte.
# print(type(requests.exceptions)) # Modul, conține cod legat de erorile din requests.

# Exercițiu 6

# import requests
# Status = requests.get(BASE_URL, timeout=TIMEOUT)
# help(requests.get)

# Exercițiu 7

# import requests
# import time
# start = time.perf_counter()
# Status = requests.get(BASE_URL, timeout=TIMEOUT)
# end = time.perf_counter()
# duration = end - start
# print(duration)
# print(Status.elapsed)

# Exercițiu 8

# try:
#     import bs4
# except ImportError:
#     print("Instalați modulul cu: pip install beautifulsoup4")

# Modul este un fișier cu cod: funcții, clase, variabile etc.
# Pachetul este o colecție de module organizate împreună.
# Biblioteca este o colecție de cod pe care o folosim în program.