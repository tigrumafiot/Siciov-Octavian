# Laborator: funcții, metode și importuri pe web
# Student: Sîciov Octavian

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiu 44

# # În webtools.py:
# import requests
# TIMEOUT = 10
# def fetch(url, timeout=TIMEOUT):
#     """Descarcă o pagină și returnează obiectul Response."""
#     return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
# def get_status(url):
#     """Returnează codul HTTP al paginii."""
#     return fetch(url).status_code
# def get_title(html):
#     """Extrage titlul dintre tag-urile title."""
#     match = re.search(r"<title[^>]*>(.*?)</title\s*>", html, flags=re.I | re.S)
#     return match.group(1).strip() if match else "Titlu lipsă"
# def security_headers(url):
#     """Verifică prezența celor cinci antete de securitate."""
#     response = fetch(url)
#     return {name: name in response.headers for name in SECURITY_HEADERS}
# # În main.py:
# import webtools
# BASE_URL = "https://cybercor.org"
# print(webtools.get_title(webtools.fetch(BASE_URL).text))

# Exercițiu 45

# from webtools import get_title, security_headers
# # Dacă main.py definește propria funcție get_title, aceasta înlocuiește numele importat.

# Exercițiu 46

# # La sfârșitul fișierului webtools.py:
# if __name__ == "__main__":
#     print("Autotest:", get_status("https://cybercor.org"))
# # Autotestul rulează doar când executăm direct webtools.py, nu când îl importăm.

# Exercițiu 47

# # În webtools.py:
# DEFAULT_HEADERS = {"User-Agent": "WebLab-Siciov-Octavian"}
# # În fetch() se transmite headers=DEFAULT_HEADERS către requests.get().
# # În main.py:
# from webtools import DEFAULT_HEADERS
# print(DEFAULT_HEADERS)

# Exercițiu 48

# import argparse
# import webtools
# parser = argparse.ArgumentParser()
# parser.add_argument("url")
# args = parser.parse_args()
# print(webtools.get_status(args.url))
# # Rulare: py main.py https://cybercor.org

# Exercițiu 49

# import csv
# from datetime import datetime
# import webtools
# rezultate = webtools.check_paths("https://cybercor.org", ["/", "/robots.txt"])
# with open("report.csv", "w", newline="", encoding="utf-8") as file:
#     writer = csv.writer(file)
#     writer.writerow(["path", "status", "checked_at"])
#     for path, status in rezultate.items():
#         writer.writerow([path, status, datetime.now().isoformat()])

# Exercițiu 50

# # În webtools.py se definește funcția site_report(url), care adună informațiile și salvează report.json.
# # În main.py:
# import webtools
# webtools.site_report("https://cybercor.org")
# # Funcția colectează status, URL final, titlu, IP, redirecționări,
# # scorul antetelor, zilele certificatului, legături și robots.txt.
# # Codul complet funcțional se află în fișierele webtools.py și main.py.
